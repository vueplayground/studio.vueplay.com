import HeaderMenu from './menu-header.js'
import FooterMenu from './menu-footer.js'

export default {
    HeaderMenu,
    FooterMenu
}