export default [{
        label: 'Terms of Service',
        route: '/terms',
    },
    {
        label: 'Privacy Policy',
        route: '/policy',
    }
]