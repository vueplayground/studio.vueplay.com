<template>
	<div class="text-slate-50 bg-slate-800 h-40">
		<slot>
			<div class="justify-center items-center h-full w-full flex">
				Add some content to footer
			</div>
		</slot>
	</div>
</template>
<script>
	export default {
		data: () => ({})
	};

</script>
<style scoped></style>